# The Study Edit — Demo Video Script

**Target length: about 3 minutes.** Record the Unity Game view or standalone desktop app at 1200 × 820. Prepare two course names and dates relative to recording day. Start with an empty list or your own disposable demo records; back up real assignments before removing them. Speak naturally and allow the clicks to finish.

**0:00–0:25 | Introduction and dashboard**

Show the masthead and three navigation buttons.

“The Study Edit is a desktop tool that helps college students organize assignments and deadlines. It is a real everyday application, not a game. I chose a black-and-white editorial style, with custom typography, simple controls, and lots of space. The dashboard shows unfinished work in due-date order.”

**0:25–1:05 | Add assignments and show urgency**

Open Add assignment. Enter “Research essay,” “History,” tomorrow's date in YYYY-MM-DD, and “Finish outline and check citations.” Save. Add “Chapter reading,” “Biology,” yesterday's date. Save and point to the order and overdue label.

“The form requires a title, course, and valid due date. Notes are optional. Saving updates the list immediately. This reading assignment is already overdue, so it appears first. The status uses text rather than relying on color. An assignment due today gets its own ‘Due today’ label.”

**1:05–1:30 | Validation and edit**

Open a new form, leave the title blank, and try saving. Then enter a title and course with an impossible date such as 2026-02-30; try again. Cancel. Edit Research essay and change the notes or deadline; save.

“Blank required fields and invalid dates display a helpful message without adding a record. Editing starts from a copy, so Cancel discards unsaved changes. After a successful edit, the dashboard reflects the new details and date order.”

**1:30–2:00 | Completed screen and delete**

Mark Research essay complete. Open Completed. Show the row, restore it, then go to Upcoming. Delete Chapter reading, first choose Keep assignment, then delete again and confirm.

“Completing an assignment moves it out of Upcoming and into the third screen, Completed. Finished work stays available, and I can restore it. Delete asks for confirmation before removing an assignment.”

**2:00–2:30 | Prove persistence**

Stop Play and start Play again, or quit and relaunch the standalone app. Show Research essay with the edited values and Chapter reading still deleted.

“Changes save locally as soon as they succeed. After restarting, my edited assignment is still here, and the deleted item remains gone. Saving is separate from rendering, and a failed save reports an error instead of pretending the change succeeded.”

**2:30–3:05 | Brief code explanation and close**

Show AssignmentStore.cs, then StudyEditApp.cs briefly. Avoid reading the code aloud.

“The project uses a List of Assignment objects to manage the collection. Each assignment has an ID, title, course, due date, notes, and completion state. AssignmentStore validates records and saves the list as JSON. StudyEditApp handles the three screens and custom interface. The scripts include comments and the README gives exact opening, running, building, and testing steps. The Study Edit brings upcoming deadlines and completed work into one simple student tool.”
