# Validation report

Final submission checks performed October 9, 2026 with Unity 6000.5.10f1.

## Passed

- Unity Hub recognizes the project; clean cache rebuild imports and compiles the source successfully.
- Main.unity opens and the dashboard runs without Unity's no-camera overlay.
- Real UI clicks navigate Upcoming, Add/Edit, and Completed.
- Adding a title, course, due date, and notes saves immediately and displays the record.
- An October 8 due date on October 9 displays OVERDUE.
- Mark complete removes work from Upcoming and shows it in Completed.
- Editing completed work updates its title and retains completion.
- Stop/restart Play reloads the revised completed record.
- Restore returns the record to Upcoming.
- Delete opens confirmation. Keep assignment preserves the record. Confirming removes the test record immediately.
- Saving a blank form displays the required-title error without creating an assignment.
- Scrolling exposes all form fields and Save/Cancel at the tested Game view size.
- Eight standalone C# validation/copy checks passed: valid record, whitespace title/course, impossible date, incorrect format, valid leap-day/past date, length limit, draft-copy isolation.
- Unity editor data checks passed: add/save/reload; edit and completion persistence; restore; deletion persistence; corrupt-file preservation; failed-save rollback.
- A macOS standalone build succeeded. Its dashboard was visually confirmed after launch.

## Test boundaries

The standalone window launched and rendered correctly, but the computer-control service could not reliably bind its input window, so standalone interactive save/restart checks were not completed. Persistence was verified in Unity Play mode and isolated Unity data checks. A Windows build was not produced or tested. Multi-monitor and assistive-technology behavior were not tested.

No student records are included in the project archive. The temporary interface test record was removed after testing. Generated Library, Logs, Temp, and UserSettings folders are excluded from the submission archive.
