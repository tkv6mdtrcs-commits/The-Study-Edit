# The Study Edit — Design Brief

**Purpose.** College students juggle deadlines across classes. The Study Edit gives them one quiet, local place to record assignments, see what is due first, and recognize finished work. It is an everyday productivity application rather than a game.

**Audience and task.** A student needs to capture an assignment quickly, revise a changing deadline, and distinguish urgent work from completed work. The application avoids account setup and opens directly to the upcoming list. It works locally on a desktop computer.

**Visual direction.** The interface borrows from a black-and-white editorial page: an oversized masthead, numbered navigation, generous spacing, simple type, and flat monochrome panels. Black primary actions contrast with lighter secondary actions. Status is written explicitly as OVERDUE, DUE TODAY, UPCOMING, or COMPLETED, so meaning does not depend on color. All controls use custom styles and generated solid textures; no default Unity graphics or game artwork appear.

**Three principal screens.** Upcoming presents unfinished assignments in ascending due-date order, with course, notes, and actions. Add/Edit offers a focused form with required title, course, and ISO date, plus optional notes. Completed retains finished work and allows edits, restoration, or deletion. Empty states explain the next action. Deletion adds a confirmation state, while validation errors keep the form available for correction.

**Behavior and data.** Students can add, edit, delete, mark complete, and restore assignments. A List<Assignment> stores records with stable IDs. Validation rejects blank required text and impossible or incorrectly formatted dates. Past dates are allowed and marked overdue. Due dates follow the computer's local calendar day. Successful changes save immediately to a local JSON file and then appear in the interface. A restart reloads the collection. Failed saves do not commit a change; unreadable files are preserved for recovery.

**Implementation and boundaries.** Beginner-friendly C# separates storage/validation from presentation. An automatically created application object means the starter scene needs no manual wiring. The intended experience is a desktop landscape window with scrolling content. The first release does not include reminders, cloud sync, accounts, collaboration, or time-of-day deadlines.

**Success criteria.** A first-time user can add an assignment without setup, identify the earliest or overdue work, move it to Completed, and retrieve the same data after restarting. Testing covers validation, persistent edits and completion, deletion, failure handling, and a manual interface walkthrough. The result satisfies the assignment's real-tool, three-screen, collection, persistent-storage, custom-UI, and approachable-code requirements.
