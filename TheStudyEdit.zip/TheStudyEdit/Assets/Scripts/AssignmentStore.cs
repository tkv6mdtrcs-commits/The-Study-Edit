using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

namespace TheStudyEdit
{
    // JsonUtility serializes fields. A wrapper lets us save a List as JSON.
    [Serializable]
    public class Assignment
    {
        public string id;
        public string title;
        public string course;
        public string dueDate; // ISO format sorts chronologically and is easy to read.
        public string notes;
        public bool completed;
        public Assignment Copy() { return (Assignment)MemberwiseClone(); }
    }

    [Serializable]
    public class AssignmentData
    {
        public int version = 1;
        public List<Assignment> assignments = new List<Assignment>();
    }

    public class AssignmentStore
    {
        public AssignmentData Data { get; private set; } = new AssignmentData();
        public string SavePath { get; private set; }
        public string LoadWarning { get; private set; } = "";
        public bool CanSave { get; private set; } = true;

        public AssignmentStore(string path) { SavePath = path; Load(); }
        public static bool TryDate(string text, out DateTime date)
        {
            return DateTime.TryParseExact(text, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                DateTimeStyles.None, out date);
        }
        public static string Validate(Assignment item)
        {
            if (string.IsNullOrWhiteSpace(item.title)) return "Add an assignment title.";
            if (string.IsNullOrWhiteSpace(item.course)) return "Add a course name.";
            DateTime date;
            if (!TryDate(item.dueDate, out date)) return "Use a real date in YYYY-MM-DD format (example: 2026-10-20).";
            if (item.title.Length > 100 || item.course.Length > 80 || (item.notes ?? "").Length > 2000)
                return "Keep the title under 100, course under 80, and notes under 2,000 characters.";
            return "";
        }
        void Load()
        {
            if (!File.Exists(SavePath)) return;
            try
            {
                var loaded = JsonUtility.FromJson<AssignmentData>(File.ReadAllText(SavePath));
                if (loaded == null || loaded.version != 1 || loaded.assignments == null)
                    throw new InvalidDataException("Unsupported or damaged save file.");
                var ids = new HashSet<string>();
                foreach (var item in loaded.assignments)
                    if (item == null || Validate(item) != "" || string.IsNullOrEmpty(item.id) || !ids.Add(item.id))
                        throw new InvalidDataException("Invalid assignment in save file.");
                Data = loaded;
            }
            catch (Exception ex)
            {
                CanSave = false; // Never overwrite unreadable work silently.
                LoadWarning = "Your save could not be read. The original is preserved. See README recovery steps. " + ex.Message;
            }
        }
        // Commit a candidate collection only AFTER its save succeeds.
        public bool Commit(List<Assignment> candidate, out string error)
        {
            error = "";
            if (!CanSave) { error = LoadWarning; return false; }
            try
            {
                var next = new AssignmentData { assignments = candidate };
                Directory.CreateDirectory(Path.GetDirectoryName(SavePath));
                string temporary = SavePath + ".tmp";
                File.WriteAllText(temporary, JsonUtility.ToJson(next, true));
                if (File.Exists(SavePath)) File.Copy(SavePath, SavePath + ".bak", true);
                // Replace keeps the previous primary file intact if replacement fails.
                if (File.Exists(SavePath)) File.Replace(temporary, SavePath, null);
                else File.Move(temporary, SavePath);
                Data = next;
                return true;
            }
            catch (Exception ex) { error = "Could not save. Your change was not applied. " + ex.Message; return false; }
        }
        public List<Assignment> CopyItems()
        {
            var result = new List<Assignment>();
            foreach (var item in Data.assignments) result.Add(item.Copy());
            return result;
        }
    }
}
