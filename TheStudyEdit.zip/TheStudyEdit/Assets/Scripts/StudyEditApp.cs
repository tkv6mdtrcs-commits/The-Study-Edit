using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace TheStudyEdit
{
    // All UI is drawn with our own styles and solid textures: no stock Unity controls or sprites.
    public class StudyEditApp : MonoBehaviour
    {
        enum ScreenState { Dashboard, Form, Completed }
        ScreenState screen;
        ScreenState returnScreen;
        AssignmentStore store;
        Assignment draft;
        Assignment pendingDelete;
        string message = "";
        Vector2 scroll;
        GUIStyle body, small, heading, masthead, button, primary, input, notes, card;
        Texture2D white, black, grey;
        Font font;
        DateTime displayedDay;
        float scale;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Boot()
        {
            if (FindAnyObjectByType<StudyEditApp>() == null)
                new GameObject("The Study Edit").AddComponent<StudyEditApp>();
        }
        void Awake()
        {
            Application.targetFrameRate = 30;
            // A clear-only camera prevents the editor's no-camera overlay over our UI.
            var cameraObject = new GameObject("UI Background Camera");
            cameraObject.transform.SetParent(transform);
            var backgroundCamera = cameraObject.AddComponent<Camera>();
            backgroundCamera.clearFlags = CameraClearFlags.SolidColor;
            backgroundCamera.backgroundColor = Color.white;
            backgroundCamera.cullingMask = 0;
            store = new AssignmentStore(Path.Combine(Application.persistentDataPath, "assignments.json"));
            message = store.LoadWarning;
            displayedDay = DateTime.Today;
        }
        void Update()
        {
            if (DateTime.Today != displayedDay) { displayedDay = DateTime.Today; }
        }
        Texture2D Solid(Color color)
        {
            var texture = new Texture2D(1, 1); texture.SetPixel(0, 0, color); texture.Apply(); return texture;
        }
        GUIStyle Text(int size, bool bold = false)
        {
            return new GUIStyle { font = font, fontSize = size, fontStyle = bold ? FontStyle.Bold : FontStyle.Normal,
                normal = { textColor = Color.black }, wordWrap = true };
        }
        GUIStyle Control(bool filled)
        {
            var s = Text(15, true);
            s.alignment = TextAnchor.MiddleCenter;
            s.padding = new RectOffset(14, 14, 10, 10);
            s.normal.background = filled ? black : grey;
            s.normal.textColor = filled ? Color.white : Color.black;
            s.hover.background = filled ? grey : black;
            s.hover.textColor = filled ? Color.black : Color.white;
            s.active.background = black; s.active.textColor = Color.white;
            s.focused.background = black; s.focused.textColor = Color.white;
            return s;
        }
        void Styles()
        {
            if (body != null) return;
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            white = Solid(Color.white); black = Solid(Color.black); grey = Solid(new Color(.91f, .91f, .91f));
            body = Text(18); small = Text(13); heading = Text(36, true); masthead = Text(54, true);
            button = Control(false); primary = Control(true);
            input = Text(18); input.padding = new RectOffset(12, 12, 12, 12);
            input.normal.background = grey; input.focused.background = white;
            input.focused.textColor = Color.black;
            notes = new GUIStyle(input) { wordWrap = true };
            card = Text(18); card.normal.background = grey; card.padding = new RectOffset(22, 22, 18, 18);
        }
        bool Button(string text, bool dark = false, float width = 0)
        {
            return width > 0 ? GUILayout.Button(text, dark ? primary : button, GUILayout.Width(width), GUILayout.Height(44))
                : GUILayout.Button(text, dark ? primary : button, GUILayout.Height(44));
        }
        void OnGUI()
        {
            Matrix4x4 previousMatrix = GUI.matrix;
            try
            {
            Styles();
            // Keep text readable at small resolutions; vertical content scrolls independently.
            scale = Mathf.Min(1.5f, Mathf.Max(.5f, UnityEngine.Screen.width / 1000f));
            GUI.matrix = Matrix4x4.Scale(new Vector3(scale, scale, 1));
            float width = UnityEngine.Screen.width / scale;
            float height = UnityEngine.Screen.height / scale;
            GUI.DrawTexture(new Rect(0, 0, width, height), white);
            GUILayout.BeginArea(new Rect(42, 24, width - 84, height - 40));
            GUILayout.Label("STUDENT TOOLS / VOL. 01", small);
            GUILayout.Label("The Study Edit", masthead);
            GUILayout.Label("A little structure. A clearer semester.", body);
            GUILayout.Space(18);
            GUILayout.BeginHorizontal();
            if (Button("01  Upcoming", screen == ScreenState.Dashboard)) Navigate(ScreenState.Dashboard);
            if (Button("02  Add assignment", screen == ScreenState.Form)) OpenForm(null);
            if (Button("03  Completed", screen == ScreenState.Completed)) Navigate(ScreenState.Completed);
            GUILayout.EndHorizontal();
            GUILayout.Space(14);
            if (!string.IsNullOrEmpty(message)) { GUILayout.Label(message, body); GUILayout.Space(10); }
            scroll = GUILayout.BeginScrollView(scroll, GUIStyle.none, GUIStyle.none);
            if (pendingDelete != null) DeleteDialog();
            else if (screen == ScreenState.Form) Form();
            else ListScreen(screen == ScreenState.Completed);
            GUILayout.EndScrollView();
            GUILayout.Space(8);
            GUILayout.Label("LOCAL FIRST  /  " + DateTime.Today.ToString("dd MMM yyyy").ToUpperInvariant() + "  /  Due dates end at midnight", small);
            GUILayout.EndArea();
            }
            finally { GUI.matrix = previousMatrix; }
        }
        void Navigate(ScreenState state)
        {
            screen = state; pendingDelete = null; scroll = Vector2.zero;
            GUIUtility.ExitGUI();
        }
        void OpenForm(Assignment item)
        {
            if (screen != ScreenState.Form) returnScreen = screen;
            draft = item == null ? new Assignment { id = Guid.NewGuid().ToString(), title = "", course = "",
                dueDate = DateTime.Today.ToString("yyyy-MM-dd"), notes = "" } : item.Copy();
            message = store.LoadWarning; Navigate(ScreenState.Form);
        }
        void ListScreen(bool completed)
        {
            var visible = store.CopyItems().FindAll(a => a.completed == completed);
            visible.Sort((a, b) => { int order = string.CompareOrdinal(a.dueDate, b.dueDate);
                return order == 0 ? string.CompareOrdinal(a.title, b.title) : order; });
            GUILayout.Label(completed ? "The finished chapter." : "What's next.", heading);
            GUILayout.Label(visible.Count + (completed ? " completed assignments" : " upcoming assignments") + " / earliest due date first", small);
            GUILayout.Space(20);
            if (visible.Count == 0)
            {
                GUILayout.Label(completed ? "Your finished work will live here." : "A clean slate. Add your first assignment.", body);
                if (!completed && Button("+ Add an assignment", true)) OpenForm(null);
            }
            foreach (var item in visible)
            {
                GUILayout.BeginVertical(card);
                DateTime due; AssignmentStore.TryDate(item.dueDate, out due);
                string status = item.completed ? "COMPLETED" : due < DateTime.Today ? "OVERDUE" : due == DateTime.Today ? "DUE TODAY" : "UPCOMING";
                GUILayout.Label(status + "  /  " + due.ToString("ddd, dd MMM yyyy").ToUpperInvariant(), small);
                GUILayout.Label(item.title, heading);
                GUILayout.Label(item.course, body);
                if (!string.IsNullOrWhiteSpace(item.notes)) GUILayout.Label(item.notes, body);
                GUILayout.Space(12);
                GUILayout.BeginHorizontal();
                if (Button(item.completed ? "Restore to upcoming" : "Mark complete", true)) SetCompleted(item);
                if (Button("Edit", false, 90)) OpenForm(item);
                if (Button("Delete", false, 90)) { pendingDelete = item; scroll = Vector2.zero; GUIUtility.ExitGUI(); }
                GUILayout.EndHorizontal(); GUILayout.EndVertical(); GUILayout.Space(12);
            }
        }
        void Field(string label, ref string value, int max, bool multiline = false)
        {
            GUILayout.Label(label, small);
            value = multiline ? GUILayout.TextArea(value ?? "", max, notes, GUILayout.Height(120))
                : GUILayout.TextField(value ?? "", max, input, GUILayout.Height(48));
            GUILayout.Space(16);
        }
        void Form()
        {
            bool editing = store.Data.assignments.Exists(a => a.id == draft.id);
            GUILayout.Label(editing ? "Revise the plan." : "Make room for what's next.", heading);
            GUILayout.Label("Required: title, course, due date. Past dates are allowed and marked overdue.", small);
            GUILayout.Space(22);
            Field("ASSIGNMENT TITLE *", ref draft.title, 100);
            Field("COURSE *", ref draft.course, 80);
            Field("DUE DATE *  /  YYYY-MM-DD", ref draft.dueDate, 10);
            Field("NOTES  /  OPTIONAL", ref draft.notes, 2000, true);
            GUILayout.BeginHorizontal();
            if (Button("Save assignment", true))
            {
                draft.title = draft.title.Trim(); draft.course = draft.course.Trim(); draft.dueDate = draft.dueDate.Trim();
                message = AssignmentStore.Validate(draft);
                if (message == "")
                {
                    var candidate = store.CopyItems(); int index = candidate.FindIndex(a => a.id == draft.id);
                    if (index < 0) candidate.Add(draft.Copy()); else candidate[index] = draft.Copy();
                    if (Save(candidate, "Assignment saved locally.")) Navigate(draft.completed ? ScreenState.Completed : ScreenState.Dashboard);
                }
            }
            if (Button("Cancel")) Navigate(returnScreen);
            GUILayout.EndHorizontal();
        }
        bool Save(List<Assignment> candidate, string success)
        {
            string error;
            if (!store.Commit(candidate, out error)) { message = error; return false; }
            message = success; return true;
        }
        void SetCompleted(Assignment item)
        {
            var candidate = store.CopyItems(); candidate.Find(a => a.id == item.id).completed = !item.completed;
            Save(candidate, item.completed ? "Assignment restored." : "Assignment completed. Find it in Completed.");
            GUIUtility.ExitGUI();
        }
        void DeleteDialog()
        {
            GUILayout.Label("Remove this assignment?", heading);
            GUILayout.Label(pendingDelete.title + "\nThis permanently removes it from your list.", body);
            GUILayout.Space(20); GUILayout.BeginHorizontal();
            if (Button("Delete assignment", true))
            {
                var candidate = store.CopyItems(); candidate.RemoveAll(a => a.id == pendingDelete.id);
                if (Save(candidate, "Assignment deleted.")) pendingDelete = null;
                GUIUtility.ExitGUI();
            }
            if (Button("Keep assignment")) { pendingDelete = null; GUIUtility.ExitGUI(); }
            GUILayout.EndHorizontal();
        }
        void OnDestroy()
        {
            if (white != null) Destroy(white); if (black != null) Destroy(black); if (grey != null) Destroy(grey);
        }
    }
}
