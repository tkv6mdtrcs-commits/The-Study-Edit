using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace TheStudyEdit
{
    public static class StudyEditChecks
    {
        [MenuItem("The Study Edit/Run data checks")]
        public static void Run()
        {
            string directory = Path.Combine(Path.GetTempPath(), "StudyEditChecks-" + Guid.NewGuid());
            string path = Path.Combine(directory, "assignments.json");
            try
            {
                var store = new AssignmentStore(path);
                var item = new Assignment { id = "one", title = "Essay", course = "History", dueDate = "2026-10-20", notes = "Draft" };
                Check(AssignmentStore.Validate(item) == "", "Valid assignment");
                item.dueDate = "2026-02-30"; Check(AssignmentStore.Validate(item) != "", "Invalid date rejected");
                item.dueDate = "2026-10-20"; item.title = " "; Check(AssignmentStore.Validate(item) != "", "Blank title rejected");
                item.title = "Essay";
                string error; var list = store.CopyItems(); list.Add(item);
                Check(store.Commit(list, out error), "Add saved: " + error);
                var reloaded = new AssignmentStore(path);
                Check(reloaded.Data.assignments.Count == 1 && reloaded.Data.assignments[0].notes == "Draft", "Restart persistence");
                list = reloaded.CopyItems(); list[0].title = "Revised essay"; list[0].completed = true;
                Check(reloaded.Commit(list, out error), "Edit and complete saved");
                reloaded = new AssignmentStore(path);
                Check(reloaded.Data.assignments[0].completed && reloaded.Data.assignments[0].title == "Revised essay", "Edit and complete persisted");
                list = reloaded.CopyItems(); list[0].completed = false;
                Check(reloaded.Commit(list, out error), "Restore saved");
                list.Clear(); Check(reloaded.Commit(list, out error), "Delete saved");
                Check(new AssignmentStore(path).Data.assignments.Count == 0, "Delete persists");
                File.WriteAllText(path, "broken json"); reloaded = new AssignmentStore(path);
                Check(!reloaded.CanSave && !reloaded.Commit(list, out error) && File.ReadAllText(path) == "broken json", "Corruption preserved");
                var blocked = new AssignmentStore(Path.Combine(directory, "blocked", "save.json"));
                File.WriteAllText(Path.Combine(directory, "blocked"), "not a directory");
                list.Add(item); Check(!blocked.Commit(list, out error) && blocked.Data.assignments.Count == 0, "Failed save does not commit");
                Debug.Log("THE STUDY EDIT: ALL DATA CHECKS PASSED");
            }
            finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        }
        static void Check(bool condition, string name)
        {
            if (!condition) throw new Exception("Check failed: " + name);
            Debug.Log("PASS: " + name);
        }
    }
}
