using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace TheStudyEdit
{
    public static class SubmissionBuild
    {
        [MenuItem("The Study Edit/Build macOS submission")]
        public static void BuildMac()
        {
            StudyEditChecks.Run();
            string project = Path.GetDirectoryName(Application.dataPath);
            string destination = Path.Combine(Path.GetDirectoryName(project), "TheStudyEdit-macOS", "The Study Edit.app");
            Directory.CreateDirectory(Path.GetDirectoryName(destination));
            var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions {
                scenes = new[] { "Assets/Scenes/Main.unity" },
                locationPathName = destination,
                target = BuildTarget.StandaloneOSX,
                options = BuildOptions.None
            });
            if (report.summary.result != BuildResult.Succeeded)
                throw new System.Exception("Submission build failed: " + report.summary.result);
            Debug.Log("THE STUDY EDIT: MACOS BUILD SUCCEEDED: " + destination);
        }
    }
}
