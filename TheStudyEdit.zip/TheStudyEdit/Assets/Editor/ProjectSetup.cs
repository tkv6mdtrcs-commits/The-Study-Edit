using UnityEditor;
using UnityEngine;

namespace TheStudyEdit
{
    [InitializeOnLoad]
    public static class ProjectSetup
    {
        static ProjectSetup() { EditorApplication.delayCall += Configure; }
        static void Configure()
        {
            PlayerSettings.companyName = "The Study Edit";
            PlayerSettings.productName = "The Study Edit";
            PlayerSettings.defaultScreenWidth = 1200;
            PlayerSettings.defaultScreenHeight = 820;
            PlayerSettings.fullScreenMode = FullScreenMode.Windowed;
            PlayerSettings.resizableWindow = true;
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene("Assets/Scenes/Main.unity", true) };
        }
    }
}
