# The Study Edit

A real everyday desktop tool for college assignments, made in Unity with beginner-friendly C#. Black-and-white typography, custom flat controls, three distinct screens, and local JSON persistence. No game mechanics, imported art, default Unity sprites, or stock button graphics.

## Open and run — exact steps

1. Extract `TheStudyEdit.zip` if you received the archive. Keep Assets, Packages, and ProjectSettings together inside TheStudyEdit.
2. Install **Unity Hub** and **Unity Editor 6000.5.10f1**, the version used for this project. In Hub, use Installs → Install Editor (or Unity's download archive). Include your desktop platform's Build Support if you want an executable.
3. In Unity Hub, choose Projects → Add → Add project from disk. Select the **TheStudyEdit** folder, not its Assets subfolder.
4. Open the project with 6000.5.10f1. Wait for import and compilation. Unity generates Library and other local settings automatically.
5. In the Project panel, open **Assets → Scenes → Main** by double-clicking Main.
6. Open Window → General → Game. Set the Game view to a landscape resolution such as **1200 × 820**, and press Play at the top of the editor.
7. The Study Edit appears automatically. The scene is intentionally empty: `StudyEditApp.Boot()` creates the application object when Play starts. No Inspector wiring is needed.
8. Select **02 Add assignment**, enter a title and course, use a due date such as `2026-10-20`, add optional notes, and click Save assignment. All successful changes save immediately.
9. Stop Play and press Play again. Your assignment should still appear. Exit Unity and reopen to test a full application restart.

## Use the three screens

- **Upcoming:** all unfinished work, sorted earliest due date first. A past date is OVERDUE; today's date is DUE TODAY. Due dates refer to the computer's local calendar day, with no separate time-of-day entry.
- **Add / Edit:** title, course, date, and optional notes. Required fields reject blank/whitespace input. Dates must be real calendar dates in `YYYY-MM-DD`. Title: 100 characters; course: 80; notes: 2,000. Cancel discards the unsaved form.
- **Completed:** finished work, also sorted by due date. Restore returns an assignment to Upcoming. Editing completed work retains its completed state.
- **Delete:** opens a confirmation state. Keep assignment cancels; Delete assignment commits the deletion.

Switching away from an unsaved form discards its edits. Dates in the past are deliberately allowed. There are no notifications, accounts, cloud sync, or recurring assignments. The lists start empty; your own work supplies the data. Long lists scroll with the mouse wheel or trackpad. The layout scales with window width and scrolls vertically; desktop landscape is the intended format.

## Build a standalone desktop app

1. Stop Play. Open File → Build Profiles.
2. Choose your desktop platform. Install its support module through Hub if Unity asks; switch to that platform.
3. Verify **Assets/Scenes/Main.unity** is enabled in the scene list. ProjectSetup includes it automatically.
4. Choose Build and Run. Save the build in a new **Builds** folder inside the project.
5. Add an assignment, quit the built app, relaunch it, and confirm it survived.

Editor and desktop builds use the same company/product identifiers and can share the same local save location on one computer. Do not run both simultaneously: this is a single-user, single-instance tool.

## Where saving happens

`AssignmentStore` writes `assignments.json` under `Application.persistentDataPath`:

- macOS: normally `~/Library/Application Support/The Study Edit/The Study Edit/assignments.json`.
- Windows: normally `%USERPROFILE%\AppData\LocalLow\The Study Edit\The Study Edit\assignments.json`.

On other platforms, Unity determines the path. The tool targets desktop; WebGL saving is not supported by this file-based implementation.

Saving writes a temporary JSON file, preserves the previous primary save as `.bak`, and replaces the primary file. The in-memory collection updates only after saving succeeds. A failure displays an error and keeps the current list. Local files are plain text, so this is not encrypted storage.

If a save is unreadable, the app blocks changes and preserves it. To recover: close the app; copy the entire save folder somewhere safe; rename `assignments.json` to `assignments.damaged.json`; if a valid `.bak` exists, copy it as `assignments.json`; reopen the app. Without a backup, renaming the damaged file starts a fresh empty list. Keep the damaged copy for manual recovery. Never edit the file while the app is running.

## Beginner's code map

- `Assets/Scripts/AssignmentStore.cs`: Assignment fields, a `List<Assignment>` collection, validation, loading, copying, and committing JSON saves. The serializable wrapper allows Unity's JsonUtility to save the list.
- `Assets/Scripts/StudyEditApp.cs`: screen enum, custom styles, navigation, form, sorted lists, and add/edit/delete/complete actions. `OnGUI` renders the UI. Solid textures and explicit GUIStyle instances replace Unity's default visual skin.
- `Assets/Editor/ProjectSetup.cs`: sets window size, product name, and build scene automatically in the editor.
- `Assets/Editor/StudyEditChecks.cs`: isolated data checks using temporary files, separate from your personal assignments.

Suggested learning order: Assignment → Validate → CopyItems → Commit → OpenForm → Form → ListScreen. `draft` is a copy so Cancel cannot change a saved assignment. IDs identify assignments even if two have the same title. Sorting copies leaves the stored collection intact.

## Test checklist

Run **The Study Edit → Run data checks** in Unity's menu. The Console should show `ALL DATA CHECKS PASSED`. These checks cover valid/invalid dates, whitespace validation, add/reload, edit/completion persistence, restore, deletion persistence, unreadable-save protection, and failed-save rollback.

Also perform these interface checks manually:

1. Add “Essay” / “History” / tomorrow's date; verify it appears immediately.
2. Add “Reading” with yesterday's date; verify OVERDUE and that it sorts before Essay. Add today's date and verify DUE TODAY.
3. Try blank title, blank course, `2026-02-30`, and `10/20/2026`; verify an error and no added item.
4. Edit Essay's title/date/notes; save and check the row and order update. Edit again, Cancel, and verify the old data remains.
5. Mark complete; verify disappearance from Upcoming and appearance in Completed. Restore and check the reverse.
6. Delete → Keep assignment should preserve the item; confirm deletion should remove it immediately and after restart.
7. Stop/restart Play, then quit/reopen Unity; verify all saved values and completion state.
8. Add enough rows to scroll; test long titles/notes, resize the Game view, and verify all form actions remain reachable by scrolling.
9. Build and restart the desktop executable to verify the final platform save path.

See `VALIDATION.md` for what was actually checked during creation. `Design-Brief.md` and `Demo-Video-Script.md` are submission-ready supporting documents.

Unity API references: [persistentDataPath](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Application-persistentDataPath.html), [JsonUtility](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/JsonUtility.html), [GUIStyle](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/GUIStyle.html).

## Submission files

Submit **TheStudyEdit-Submission.zip** for the complete source project and written documents. It includes Assets, Packages, ProjectSettings, this README, the design brief, demo script, and validation report. The optional **TheStudyEdit-macOS.zip** contains a built Mac application; it supplements the source project. For another operating system, build from the source using the steps above.

You can also generate the Mac build inside Unity with **The Study Edit → Build macOS submission** after stopping Play. That menu runs the data checks before building.

The supplied demo is a script, not a recorded video. If your instructor requires a video file, record the approximately three-minute walkthrough in Demo-Video-Script.md and submit that recording separately.
